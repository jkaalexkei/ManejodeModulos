def suma(v1,v2):
    print("la suma es: ", str(v1+v2))

def resta(v1,v2):
    print("la suma es: ", str(v1-v2))

def multiplicar(v1,v2):
    print("la suma es: ", str(v1*v2))

def dividir(v1,v2):
    print("la suma es: ", str(v1/v2))
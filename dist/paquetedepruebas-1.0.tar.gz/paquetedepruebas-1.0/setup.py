
from setuptools import setup

setup(
    name="paquetedepruebas",
    version="1.0",
    description="paquete de pruebas",
    author="Alexander Varela",
    author_email="jkaalexkei@gmail.com",
    url="https://github.com/jkaalexkei",
    packages=["paquetes","paquetes.operacionesbasicas"]
)